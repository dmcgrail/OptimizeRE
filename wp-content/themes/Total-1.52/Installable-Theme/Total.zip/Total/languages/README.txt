~~ IMPORTANT ~~

We need your help! We'll gladly accept any translation you can provide. Please contact us via ThemeForest if you have translated the theme.

Thank you!


——————————————————————————

Special thanks to the following people for language translations:

ITALIAN = @Diego Meozzi - http://themeforest.net/user/nightjar
SWEDISH - http://themeforest.net/user/junkyhlm