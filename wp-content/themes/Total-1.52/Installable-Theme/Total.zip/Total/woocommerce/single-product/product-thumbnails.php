<?php
/**
 * Single Product Thumbnails
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.3
 */

return;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}