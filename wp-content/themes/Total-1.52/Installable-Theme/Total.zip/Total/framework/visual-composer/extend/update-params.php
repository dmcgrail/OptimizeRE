<?php
/**
 * Updates old param values to use new VC params.
 *
 * @package WordPress
 * @subpackage Total
 * @since Total 1.4
 */

/** Work In Progress: http://kb.wpbakery.com/index.php?title=Update_single_param_values **/