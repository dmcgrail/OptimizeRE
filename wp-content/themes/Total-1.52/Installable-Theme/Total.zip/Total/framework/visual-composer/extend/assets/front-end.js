(function($) {
	$('.vc-transparent').on( 'hover', function(){
		$('.vc-panel-message').hide();
	} );
})(jQuery);