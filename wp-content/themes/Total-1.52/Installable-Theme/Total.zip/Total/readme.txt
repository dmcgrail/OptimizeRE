Dear customer, First of all, thank you for your purchase!

If you happen to face some difficulties with this theme, consider to use our support which is conducted through ThemeForest.

Don’t forget to first read through the Documentation (included) and the FAQ (link below) before asking questions, it saves us both a lot of time!

===

THEME FAQ:

http://themeforest.net/item/total-responsive-multipurpose-wordpress-theme/6339019/support?ref=WPExplorer

====

Thank you,
AJ Clarke @ WPExplorer

All the best and have a nice day